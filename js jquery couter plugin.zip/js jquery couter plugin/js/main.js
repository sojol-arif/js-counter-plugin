$(document).ready(function(){
	$('#nav').slicknav();
	 $("#responsive-videos").fitVids();
	 $('.my-plugin-counter').countTo({from: 0, to: 500});
});